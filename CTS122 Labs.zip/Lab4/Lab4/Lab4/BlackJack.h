#ifndef BlackJack_h
#define BlackJack_h

#include "Deck.h"
#include <string>

using namespace std;

//class BlackJack
//{
//
//private:
//
//
//public:
//
//	BlackJack()
//	{
//
//
//	}
//
//	void playGame()
//	{
//
//
//	}
//
//
//
//};

void playGame(void);


void printIntro(void);










#endif