#include "StringSplitter.h"
#include "Lab11.h"

#include <iostream>

int main(void)
{
	std::string input = "";
	input = getInput();
	std::cout << "Evaluating: " << input << endl;



	return 0;
}