#ifndef Lab11_h
#define Lab11_h

#include <string>

std::string getInput();



#endif