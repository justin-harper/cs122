#ifndef DoublyLinkedList_h
#define DoublyLInkedList_h


class DoublyLinkedList
{
public:
	DoublyLinkedList();
	~DoublyLinkedList();


};

#endif