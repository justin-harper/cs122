#pragma once

/*
Justin Harper
10696738

version 1.0
*/


#include <iostream>
#include <string>
#include <sstream>


int getCheckLanes();

int getRandBound();