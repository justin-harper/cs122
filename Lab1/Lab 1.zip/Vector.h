#ifndef VECTOR_H
#define VECTOR_H

typedef struct IntVector_t
{
	int size;
	int *items;
} IntVector_t;

//initialization function for int vectors
IntVector_t intVector_init(int initial_size);

//resize operation for int vectors
void intVector_resize(IntVector_t *some_vector, int new_size);

//Inserts a value at the given location
void intVector_insert(IntVector_t *some_vector,
	int location,
	int value
	);

//Adds a value at the given location.  Will shift all other
//values to the right by 1
void intVector_add(IntVector_t *some_vector, int location, int value);

#endif