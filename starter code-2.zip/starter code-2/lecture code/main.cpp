/* 
Homework 4 starter code
*/
#include <iostream> //C++ I/O 
#include <string>   //C++ Strings
#include <iomanip>  //C++ I/O formatting
#include "SkipList.h"
#include "SortedCollection.h"
#include "Vector.h"
using namespace std;

int main(int argc, char *argv[])
{
	//TODO: remove this test code
	SkipList<int> sl_numbers{};
	sl_numbers.addElement(1);
	sl_numbers.addElement(2);
	sl_numbers.addElement(3);
	sl_numbers.addElement(4);
	sl_numbers.addElement(5);

	//skip list tests
	bool found = sl_numbers.containsElement(3);
	sl_numbers.removeElement(2);
	for (int i = 0; i < sl_numbers.getSize(); i++)
	{
		cout << sl_numbers.getElementAt(i);
	}
	cout << endl;

	//sorted collection tests
	SortedCollection<int> sc_numbers{ new Vector<int>{} };
	sc_numbers.addElement(1);
	sc_numbers.addElement(2);
	sc_numbers.addElement(3);
	sc_numbers.addElement(4);
	sc_numbers.addElement(5);

	found = sc_numbers.containsElement(3);
	sc_numbers.removeElement(2);

	for (int i = 0; i < sc_numbers.getSize(); i++)
	{
		cout << sc_numbers.getElementAt(i);
	}
	cout << endl;

	//TODO: perform benchmarks
    return 0;
}


