#ifndef BENCHMARK_H
#define BENCHMARK_H

#include "Indexed.h"
#include "Stack.h"
#include "Queue.h"
#include "IndexedSorter.h"
#include "RandomNumberGenerator.h"
#include <unordered_map>
#include <string>
#include "HashTableBase.h"

#include <chrono>

using namespace chrono;
using namespace std;

class Benchmark
{
public:

	//example benchmark that can be used to test generic collections (including BST)
	//cannot be used as one of the three required benchmarks
	static long long orderedInsertBenchmark(Collection<int> &data, int max_items)
	{
		system_clock::time_point start;
		system_clock::time_point end;
		start = system_clock::now();

		//insert data
		for (int i = 0; i < max_items; i++)
		{
			data.addElement(i);
		}

		end = system_clock::now();
		return duration_cast<milliseconds>(end - start).count();
	}

	//example benchmark that can be used to test generic collections (including BST)
	//cannot be used as one of the three required benchmarks
	static long long randomInsertBenchmark(Collection<int> &data, int max_items)
	{
		system_clock::time_point start;
		system_clock::time_point end;
		RandomNumberGenerator rng{};
		start = system_clock::now();

		//insert data
		for (int i = 0; i < max_items; i++)
		{
			data.addElement(rng.getInt(0, 1000));
		}

		end = system_clock::now();
		return duration_cast<milliseconds>(end - start).count();
	}
};
#endif