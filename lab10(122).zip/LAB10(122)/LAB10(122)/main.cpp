#include "OpOV.h"
#include "Stringsplitter.h"


int main (void)
{
	int flag = 0;
	string answer; 
	while (flag ==0)
	{
		cout <<"equation to eval:"<<endl;
		string str;
		getline(cin, str);
		Operation operation(str);
		cout << operation.stringOP() << endl;

		cout << "continue?" << endl;
		getline(cin, answer);
		if (answer == "yes")
		{
			flag = 0;
		}
		else 
		{
			flag = 1;
		}

	}





}