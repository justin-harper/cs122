#ifndef DEFINE1
#define DEFINE1

#include "Stringsplitter.h"
#include <string>
#include <iomanip>
#include <vector>
#include <sstream>
#include <iostream>
#include <stack>

using namespace std;

class Operation 
{
private:
	string _string_for_eval;
	vector<string> string_pieces;
	stack<double> evalstack; 
public:

	Operation(string string_for_eval)
	{

		_string_for_eval = string_for_eval;

	}

	double stringOP()
	{

		double holder = 0.0;
		double part1 = 0.0;
		double part2 = 0.0; 
		double partialanswer =0.0;
		string_pieces = StringSplitter::split(_string_for_eval," ");
		for (int j = 0; j <string_pieces.size(); j++)
		{

			if (string_pieces[j] == "/")
			{

				try
				{
					if (evalstack.size() < 2)
					{
					
						throw "not enough numbers to compute. breaking";
						break;
					
					}
					part1 = evalstack.top();
					evalstack.pop();
					part2 = evalstack.top();
					evalstack.pop();

					partialanswer = part1/part2;
					evalstack.push(partialanswer);

				}
				catch(...)
				{

					cout << "problem occured. continuing" << endl;
					continue; 

				}

			}
			else if (string_pieces[j] == "+")
			{
				try
				{
					if (evalstack.size() < 2)
					{
					
						throw "not enough numbers to compute. breaking";
						
					
					}
					part1 = evalstack.top();
					evalstack.pop();
					part2 = evalstack.top();
					evalstack.pop();

					partialanswer = part1+part2;
					evalstack.push(partialanswer);

				}
				catch(...)
				{

					cout << "problem occured. continuing" << endl;
					break; 

				}

			}
			else if (string_pieces[j] == "-")
			{
				try
				{
					if (evalstack.size() < 2)
					{
					
						throw "not enough numbers to compute. breaking";
						
					
					}
					part1 = evalstack.top();
					evalstack.pop();
					part2 = evalstack.top();
					evalstack.pop();

					partialanswer = part1-part2;
					evalstack.push(partialanswer);

				}
				catch(...)
				{

					cout << "problem occured. continuing" << endl;
					break; 

				}

			}
			else if (string_pieces[j] == "*")
			{
				try
				{
					if (evalstack.size() < 2)
					{
					
						throw "not enough numbers to compute. breaking";
						
					
					}
					part1 = evalstack.top();
					evalstack.pop();
					part2 = evalstack.top();
					evalstack.pop();
					partialanswer = part1*part2;
					evalstack.push(partialanswer);
				}
				catch(...)
				{

					cout << "problem occured. breaking" << endl;
					break; 

				}

			}
			else 
			{

				try
				{
					holder = stod(string_pieces[j]);
					evalstack.push(holder);
				}
				catch(...)
				{

					cout << "problem occured, the opperand was not any of the operators or a double" << endl; 

				}


			}

		}
		return partialanswer; 
	}




};


#endif
